#
# Copyright (C) 2015  FreeIPA Contributors see COPYING for license
#

'''
Module containing platform-specific functionality for every platform.
'''

NAME = "fedora"

# FIXME: too much cyclic dependencies
# from fedora import paths, tasks, services
